
$(document).ready(function() {

	AOS.init({
             once: false,
         });
});

$(document).on("click",".header-content-menu-burguer", function() {
	$(".header-content-menu-items").toggle();
});

$(document).on("click",".header-content-menu-items > li", function() {
	$(".header-content-menu-items").css('display','none');

	if ($('.container').width()>680){
		if ($(".header-content-menu-burguer").css('display')=='none'){
		$(".header-content-menu-items").css('display','flex');
	}
	}

});
        






















